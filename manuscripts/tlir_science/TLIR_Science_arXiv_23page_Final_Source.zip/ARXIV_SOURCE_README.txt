TLIR Science 23-page arXiv source package
Main TeX file: main.tex
Compiler: pdfLaTeX; references.bbl is included directly by main.tex.
Do not upload the already-compiled TLIR_Science_Final.pdf alongside these TeX sources.
This archive includes exactly the latest source and the three original figures from:
https://github.com/wind342/gfg-training-learning-inference-experiments
Source branch: codex/tlir-science-latex
Frozen source commit: 708dab518bc89d7dd0cc4e852a78d5a683b76745
The source corresponds to TLIR_Science_Final.pdf (23 pages, 1,155,239 bytes)
Final PDF Git blob SHA1: 8cbe66545e08fd2dd2fd5087fb035f9c5be871bf

File Git blob SHAs:
9e36a459f436c67ff0cf712b8a213db63a82d6df  main.tex
b2b898e44881135ef02a2b6428480c7c8cf2c881  references.bbl
7dc88c4d8702398d112238198493ac604205b0cd  figures/figure1_tlir_closed_loop.png
74ddf9aab29af70796a600065f27c07bfa9e8b45  figures/figure2_experimental_14panel.png
636a843e3281c3de2f6800d947fe377f43233217  figures/figure2_six_system_evidence.pdf

This is a source-only package, not a PDF. No scientific manuscript edits.
